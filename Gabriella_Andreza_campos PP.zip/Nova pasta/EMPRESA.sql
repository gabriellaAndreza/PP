
CREATE DATABASE Empresa;
USE Empresa;

CREATE TABLE departamento (
    departamentoid INT PRIMARY KEY,
    nome VARCHAR(30)
);

CREATE TABLE funcionario (
    idfuncionario INT PRIMARY KEY,
    nome VARCHAR(30),
    funcao VARCHAR(30),
    dtnascto DATE,
    salario DECIMAL(7,2),
    idDepto INT,
    FOREIGN KEY (idDepto) REFERENCES departamento(departamentoid)
);

SELECT * FROM funcionario
WHERE YEAR(dtnascto) <> 1975;

SELECT * FROM funcionario
WHERE nome LIKE '%EM%';

SELECT DISTINCT funcao FROM funcionario;

SELECT f.nome 
FROM funcionario f
JOIN departamento d ON f.idDepto = d.departamentoid
WHERE f.funcao = 'Segurança' AND d.nome = 'Saneamento';

SELECT f.nome 
FROM funcionario f
JOIN departamento d ON f.idDepto = d.departamentoid
WHERE d.nome = 'RH';

SELECT f.nome, d.nome AS departamento 
FROM funcionario f
JOIN departamento d ON f.idDepto = d.departamentoid
WHERE f.salario BETWEEN 500.00 AND 1500.00;

SELECT f.* 
FROM funcionario f
JOIN departamento d ON f.idDepto = d.departamentoid
WHERE d.nome = 'TI' AND f.salario > 2000;
EXIT;