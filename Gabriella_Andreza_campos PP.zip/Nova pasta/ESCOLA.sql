CREATE DATABASE ESCOLA;
USE ESCOLA;

CREATE TABLE aluno (
    idaluno INT PRIMARY KEY,
    nome VARCHAR(45),
    dataNasc DATE,
    valorMensalidade DECIMAL(7,2),
    rg VARCHAR(45),
    telefone VARCHAR(9)
);

CREATE TABLE curso (
    idcurso INT PRIMARY KEY,
    descricao VARCHAR(45),
    cargaHoraria INT,
    diaSemana VARCHAR(45)
);

CREATE TABLE alunoCurso (
    idaluno INT,
    idcurso INT,
    PRIMARY KEY (idaluno, idcurso),
    FOREIGN KEY (idaluno) REFERENCES aluno(idaluno),
    FOREIGN KEY (idcurso) REFERENCES curso(idcurso)
);

SELECT * FROM curso;

SELECT * FROM aluno 
WHERE YEAR(dataNasc) <> 1980;

SELECT aluno.nome, curso.descricao 
FROM aluno
JOIN alunoCurso ON aluno.idaluno = alunoCurso.idaluno
JOIN curso ON alunoCurso.idcurso = curso.idcurso;

SELECT * FROM curso 
WHERE diaSemana = 'Segunda-feira';

SELECT AVG(valorMensalidade) AS mediaMensalidade 
FROM aluno 
WHERE nome LIKE 'H%';

SELECT * FROM aluno 
WHERE valorMensalidade < 230;
SELECT COUNT(*) AS totalAlunos
FROM alunoCurso
JOIN curso ON alunoCurso.idcurso = curso.idcurso
WHERE curso.descricao = 'Contabilidade' AND curso.diaSemana = 'Quarta-feira';

SELECT SUM(aluno.valorMensalidade) AS totalPago
FROM alunoCurso
JOIN aluno ON alunoCurso.idaluno = aluno.idaluno
JOIN curso ON alunoCurso.idcurso = curso.idcurso
WHERE curso.descricao = 'Informática Básica';

SELECT DISTINCT curso.descricao
FROM alunoCurso
JOIN aluno ON alunoCurso.idaluno = aluno.idaluno
JOIN curso ON alunoCurso.idcurso = curso.idcurso
WHERE YEAR(aluno.dataNasc) = 1995;

SELECT aluno.nome, aluno.telefone
FROM alunoCurso
JOIN aluno ON alunoCurso.idaluno = aluno.idaluno
JOIN curso ON alunoCurso.idcurso = curso.idcurso
WHERE curso.descricao = 'RH';

EXIT;
